package dz.ubma.tp2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // affectation des actions aux boutons
        final Button bCancel = findViewById(R.id.bCancel);
        bCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                annuler();
            }
        });

        final Button bOk = findViewById(R.id.bOk);
        bOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ok();
            }
        });
    }

    public void annuler()
    {
        Toast.makeText(this, "Vous avez cliqué sur le bouton Annuler", Toast.LENGTH_SHORT).show();
    }
    public void ok()
    {
        Toast.makeText(this, "Vous avez cliqué sur le bouton ok", Toast.LENGTH_SHORT).show();
    }
}